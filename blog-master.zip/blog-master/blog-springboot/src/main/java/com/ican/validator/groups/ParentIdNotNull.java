package com.ican.validator.groups;

/**
 * 父评论id不为空
 *
 * @author ican
 **/
public interface ParentIdNotNull {
}
