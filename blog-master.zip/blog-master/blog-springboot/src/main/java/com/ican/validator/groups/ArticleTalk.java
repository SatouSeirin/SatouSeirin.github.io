package com.ican.validator.groups;

/**
 * 文章说说组
 *
 * @author ican
 **/
public interface ArticleTalk {
}
