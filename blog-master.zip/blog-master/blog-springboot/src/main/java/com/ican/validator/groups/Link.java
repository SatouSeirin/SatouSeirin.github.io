package com.ican.validator.groups;

/**
 * 友链组
 *
 * @author ican
 **/
public interface Link {
}
