<template>
    <div class="app-container">

    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>